window.gestionaleTooltip = {
    el: null,

    ensureEl: function () {
        if (!this.el) {
            this.el = document.createElement('div');
            this.el.className = 'following-tooltip';
            document.body.appendChild(this.el);
        }
        return this.el;
    },

    show: function (text) {
        const el = this.ensureEl();
        el.textContent = text;
        el.classList.add('visible');
    },

    move: function (x, y) {
        const el = this.ensureEl();
        el.style.left = (x + 14) + 'px';
        el.style.top = (y + 18) + 'px';
    },

    hide: function () {
        if (this.el) this.el.classList.remove('visible');
    },

    attach: function (elementRef) {
        if (elementRef.dataset.tooltipAttached) return;
        elementRef.dataset.tooltipAttached = "1";
        elementRef.addEventListener('mouseenter', () => {
            const text = elementRef.getAttribute('data-tooltip-text') || '';
            this.show(text);
        });
        elementRef.addEventListener('mousemove', (e) => {
            this.move(e.clientX, e.clientY);
        });
        elementRef.addEventListener('mouseleave', () => {
            this.hide();
        });
    }
};

window.gestionaleSwipe = {
    attach: function (dotnetRef) {
        let startX = 0, startY = 0, startTime = 0;

        document.addEventListener('touchstart', (e) => {
            if (e.touches.length !== 1) return;
            startX = e.touches[0].clientX;
            startY = e.touches[0].clientY;
            startTime = Date.now();
        }, { passive: true });

        document.addEventListener('touchend', (e) => {
            if (!e.changedTouches || e.changedTouches.length !== 1) return;
            const dx = e.changedTouches[0].clientX - startX;
            const dy = e.changedTouches[0].clientY - startY;
            const dt = Date.now() - startTime;

            if (dt > 600) return;
            if (Math.abs(dy) > 60) return;
            if (Math.abs(dx) < 60) return;

            dotnetRef.invokeMethodAsync('OnSwipe', dx > 0 ? 'right' : 'left');
        }, { passive: true });
    }
};
