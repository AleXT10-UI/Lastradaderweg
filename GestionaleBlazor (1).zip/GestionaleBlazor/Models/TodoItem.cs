namespace GestionaleBlazor.Models;

public class TodoItem
{
    public int Id { get; set; }
    public string Owner { get; set; } = "";
    public string Text { get; set; } = "";
    public bool Done { get; set; }
}
