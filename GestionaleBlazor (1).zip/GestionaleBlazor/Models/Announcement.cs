namespace GestionaleBlazor.Models;

public class Announcement
{
    public int Id { get; set; }
    public string Date { get; set; } = "";
    public string Text { get; set; } = "";
    public string CheckedByCsv { get; set; } = "";
}
