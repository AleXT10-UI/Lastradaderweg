namespace GestionaleBlazor.Models;

public class AgendaNote
{
    public string Owner { get; set; } = "";
    public string Text { get; set; } = "";
}
