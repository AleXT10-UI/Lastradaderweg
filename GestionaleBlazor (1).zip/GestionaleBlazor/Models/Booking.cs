namespace GestionaleBlazor.Models;

public class Booking
{
    public int Id { get; set; }
    public string Owner { get; set; } = "";
    public string DateKey { get; set; } = "";
    public string Res { get; set; } = "";
    public double Start { get; set; }
    public double End { get; set; }
    public string Label { get; set; } = "";
    public bool AllDay { get; set; }
}
