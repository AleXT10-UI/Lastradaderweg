namespace GestionaleBlazor.Models;

public class ResourceItem
{
    public int Id { get; set; }
    public string Owner { get; set; } = "";
    public string Name { get; set; } = "";
    public int SortOrder { get; set; }
    public string? Color { get; set; }
}
