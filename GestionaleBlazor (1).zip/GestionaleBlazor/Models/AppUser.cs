namespace GestionaleBlazor.Models;

public class AppUser
{
    public string Username { get; set; } = "";
    public string PasswordHash { get; set; } = "";
    public bool CanAnnounce { get; set; }
}
