using System.Security.Cryptography;
using System.Text;
using GestionaleBlazor.Models;
using Microsoft.AspNetCore.Components.Server.ProtectedBrowserStorage;

namespace GestionaleBlazor.Services;

public class AuthService
{
    private const string AdminUsername = "admin";
    private const string AdminPassword = "derweg";
    private const string SpecialViewerEmail = "dario.volani@lastrada-derweg.org";
    private const string SessionKey = "gestionale_current_user";

    private readonly StorageService _storage;
    private readonly ProtectedSessionStorage _sessionStorage;

    public string? CurrentUser { get; private set; }

    public AuthService(StorageService storage, ProtectedSessionStorage sessionStorage)
    {
        _storage = storage;
        _sessionStorage = sessionStorage;
    }

    public bool IsAdmin() => CurrentUser == AdminUsername;
    public bool IsSpecialViewer() => CurrentUser == SpecialViewerEmail;

    public async Task<bool> CanWriteAnnouncementAsync()
    {
        if (IsAdmin() || IsSpecialViewer()) return true;
        if (CurrentUser is null) return false;
        var users = await _storage.LoadUsersAsync();
        return users.TryGetValue(CurrentUser, out var u) && u.CanAnnounce;
    }

    public async Task<bool> CanEditGlobalTimelineAsync()
    {
        if (IsAdmin()) return true;
        if (CurrentUser is null) return false;
        var users = await _storage.LoadUsersAsync();
        return users.TryGetValue(CurrentUser, out var u) && u.CanAnnounce;
    }

    public async Task<AuthResult> AttemptLoginAsync(string username, string password)
    {
        if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            return AuthResult.Fail("login.errNeedBoth");

        if (username == AdminUsername)
        {
            if (password == AdminPassword)
            {
                await CompleteLoginAsync(AdminUsername);
                return AuthResult.Ok();
            }
            return AuthResult.Fail("login.errPassword");
        }

        var users = await _storage.LoadUsersAsync();
        if (!users.TryGetValue(username, out var user))
            return AuthResult.Fail("login.errUserNotFound");

        var hashed = Sha256(password);
        if (hashed != user.PasswordHash)
            return AuthResult.Fail("login.errPassword");

        await CompleteLoginAsync(username);
        return AuthResult.Ok();
    }

    private async Task CompleteLoginAsync(string username)
    {
        CurrentUser = username;
        try
        {
            await _sessionStorage.SetAsync(SessionKey, username);
        }
        catch
        {
        }
    }

    public async Task<bool> TryRestoreSessionAsync()
    {
        try
        {
            var result = await _sessionStorage.GetAsync<string>(SessionKey);
            if (!result.Success || string.IsNullOrEmpty(result.Value)) return false;

            var saved = result.Value;
            if (saved == AdminUsername)
            {
                CurrentUser = AdminUsername;
                return true;
            }

            var users = await _storage.LoadUsersAsync();
            if (users.ContainsKey(saved))
            {
                CurrentUser = saved;
                return true;
            }
        }
        catch
        {
        }
        return false;
    }

    public async Task LogoutAsync()
    {
        CurrentUser = null;
        try
        {
            await _sessionStorage.DeleteAsync(SessionKey);
        }
        catch
        {
        }
    }

    public static string Sha256(string input)
    {
        var bytes = SHA256.HashData(Encoding.UTF8.GetBytes(input));
        var sb = new StringBuilder();
        foreach (var b in bytes) sb.Append(b.ToString("x2"));
        return sb.ToString();
    }
}

public class AuthResult
{
    public bool Success { get; init; }
    public string? ErrorKey { get; init; }

    public static AuthResult Ok() => new() { Success = true };
    public static AuthResult Fail(string errorKey) => new() { Success = false, ErrorKey = errorKey };
}
