using GestionaleBlazor.Models;

namespace GestionaleBlazor.Services;

public class BookingService
{
    private readonly StorageService _storage;
    private readonly AuthService _auth;

    public Dictionary<string, List<Booking>> Bookings { get; private set; } = new();
    public List<string> Resources { get; private set; } = new();

    private int _idCounter = 1;

    public BookingService(StorageService storage, AuthService auth)
    {
        _storage = storage;
        _auth = auth;
    }

    public async Task LoadForCurrentUserAsync()
    {
        if (_auth.CurrentUser is null) return;
        Bookings = await _storage.LoadBookingsAsync(_auth.CurrentUser);
        Resources = await _storage.LoadResourcesAsync(_auth.CurrentUser);
        _idCounter = ComputeMaxId(Bookings) + 1;
    }

    private static int ComputeMaxId(Dictionary<string, List<Booking>> bookings)
    {
        var max = 0;
        foreach (var list in bookings.Values)
            foreach (var b in list)
                if (b.Id > max) max = b.Id;
        return max;
    }

    public async Task AddBookingAsync(string dateKey, string res, double start, double end, string label, bool allDay)
    {
        if (!Bookings.TryGetValue(dateKey, out var list))
        {
            list = new List<Booking>();
            Bookings[dateKey] = list;
        }
        list.Add(new Booking
        {
            Id = _idCounter++,
            Res = res,
            Start = start,
            End = end,
            Label = label,
            AllDay = allDay
        });
        await PersistAsync();
    }

    public async Task RemoveBookingAsync(string dateKey, int id)
    {
        if (!Bookings.TryGetValue(dateKey, out var list)) return;
        list.RemoveAll(b => b.Id == id);
        if (list.Count == 0) Bookings.Remove(dateKey);
        await PersistAsync();
    }

    public List<Booking> GetForDate(string dateKey)
        => Bookings.TryGetValue(dateKey, out var list) ? list : new List<Booking>();

    private async Task PersistAsync()
    {
        if (_auth.CurrentUser is null) return;
        await _storage.SaveBookingsAsync(_auth.CurrentUser, Bookings);
    }

    public async Task SaveResourcesAsync()
    {
        if (_auth.CurrentUser is null) return;
        await _storage.SaveResourcesAsync(_auth.CurrentUser, Resources);
    }
}
