using GestionaleBlazor.Models;

namespace GestionaleBlazor.Services;

public class AgendaService
{
    private readonly StorageService _storage;
    private readonly AuthService _auth;

    public string Notes { get; set; } = "";
    public List<TodoItem> Todos { get; private set; } = new();

    private int _todoIdCounter = 1;

    public AgendaService(StorageService storage, AuthService auth)
    {
        _storage = storage;
        _auth = auth;
    }

    public async Task LoadAsync()
    {
        if (_auth.CurrentUser is null) return;
        Notes = await _storage.LoadAgendaNotesAsync(_auth.CurrentUser);
        Todos = await _storage.LoadTodosAsync(_auth.CurrentUser);
        _todoIdCounter = (Todos.Count > 0 ? Todos.Max(t => t.Id) : 0) + 1;
    }

    public async Task SaveNotesAsync()
    {
        if (_auth.CurrentUser is null) return;
        await _storage.SaveAgendaNotesAsync(_auth.CurrentUser, Notes);
    }

    public async Task AddTodoAsync(string text)
    {
        if (string.IsNullOrWhiteSpace(text)) return;
        Todos.Add(new TodoItem { Id = _todoIdCounter++, Text = text, Done = false });
        await PersistTodosAsync();
    }

    public async Task DeleteTodoAsync(int id)
    {
        Todos.RemoveAll(t => t.Id == id);
        await PersistTodosAsync();
    }

    public async Task ToggleTodoAsync(int id)
    {
        var todo = Todos.FirstOrDefault(t => t.Id == id);
        if (todo is null) return;
        todo.Done = !todo.Done;
        await PersistTodosAsync();
    }

    private async Task PersistTodosAsync()
    {
        if (_auth.CurrentUser is null) return;
        await _storage.SaveTodosAsync(_auth.CurrentUser, Todos);
    }
}
