using GestionaleBlazor.Models;

namespace GestionaleBlazor.Services;

public class AnnouncementService
{
    private readonly StorageService _storage;

    public Announcement? Current { get; private set; }

    public AnnouncementService(StorageService storage)
    {
        _storage = storage;
    }

    public async Task LoadAsync()
    {
        Current = await _storage.LoadAnnouncementAsync();
    }

    public async Task PublishAsync(string text)
    {
        Current = new Announcement
        {
            Date = DateTime.Now.ToString("dd MMMM yyyy 'alle ore' HH:mm"),
            Text = text,
            CheckedByCsv = ""
        };
        await _storage.SaveAnnouncementAsync(Current);
    }

    public async Task DeleteAsync()
    {
        Current = null;
        await _storage.DeleteAnnouncementAsync();
    }

    public async Task ToggleCheckAsync(string username)
    {
        if (Current is null) return;
        var checkedBy = GetCheckedByList();
        if (checkedBy.Contains(username))
            checkedBy.Remove(username);
        else
            checkedBy.Add(username);
        Current.CheckedByCsv = string.Join(",", checkedBy);
        await _storage.SaveAnnouncementAsync(Current);
    }

    public bool IsCheckedBy(string username)
        => GetCheckedByList().Contains(username);

    private List<string> GetCheckedByList()
        => Current is null || string.IsNullOrEmpty(Current.CheckedByCsv)
            ? new List<string>()
            : Current.CheckedByCsv.Split(',', StringSplitOptions.RemoveEmptyEntries).ToList();
}
