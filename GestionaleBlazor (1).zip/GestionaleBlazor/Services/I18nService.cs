namespace GestionaleBlazor.Services;

public class I18nService
{
    public string CurrentLang { get; private set; } = "it";

    private static readonly Dictionary<string, Dictionary<string, string>> Dict = new()
    {
        ["it"] = new()
        {
            ["app.title"] = "Gestionale",
            ["login.title"] = "LOGIN",
            ["login.username"] = "E-Mail",
            ["login.password"] = "Password",
            ["login.submit"] = "Accedi",
            ["login.errNeedBoth"] = "Inserisci nome utente e password.",
            ["login.errPassword"] = "Password errata.",
            ["login.errUserNotFound"] = "Utente non trovato.",
            ["nav.today"] = "Oggi",
            ["view.day"] = "Giorno",
            ["view.week"] = "Settimana",
            ["view.agenda"] = "Agenda",
            ["view.global"] = "Globale",
            ["detail.allDay"] = "Tutto il giorno",
            ["detail.description"] = "Descrizione",
            ["detail.day"] = "Giorno",
            ["detail.time"] = "Orario",
            ["detail.close"] = "Chiudi",
            ["detail.delete"] = "Elimina",
            ["week.empty"] = "Nessun elemento",
            ["agenda.empty"] = "Nessun evento in programma.",
            ["agenda.notesTitle"] = "Appunti",
            ["agenda.todoTitle"] = "Da fare",
            ["agenda.todoAdd"] = "Aggiungi",
            ["modal.newItem"] = "Nuovo elemento",
            ["modal.resource"] = "Risorsa",
            ["modal.from"] = "Dalle",
            ["modal.to"] = "Alle",
            ["modal.description"] = "Descrizione",
            ["modal.cancel"] = "Annulla",
            ["modal.save"] = "Salva",
            ["resources.title"] = "Gestisci risorse",
            ["resources.add"] = "Aggiungi",
            ["resources.close"] = "Chiudi",
            ["global.readonlyHint"] = "Sola lettura — solo gli amministratori possono modificare",
            ["detail.empty"] = "Nessun elemento.",
            ["users.title"] = "Gestisci utenti",
            ["users.close"] = "Chiudi",
            ["users.create"] = "Crea",
        },
        ["de"] = new()
        {
            ["app.title"] = "Verwaltung",
            ["login.title"] = "Anmelden",
            ["login.username"] = "E-Mail",
            ["login.password"] = "Passwort",
            ["login.submit"] = "Anmelden",
            ["login.errNeedBoth"] = "Bitte Benutzername und Passwort eingeben.",
            ["login.errPassword"] = "Falsches Passwort.",
            ["login.errUserNotFound"] = "Benutzer nicht gefunden.",
            ["nav.today"] = "Heute",
            ["view.day"] = "Tag",
            ["view.week"] = "Woche",
            ["view.agenda"] = "Termine",
            ["view.global"] = "Global",
            ["detail.allDay"] = "Ganztägig",
            ["detail.description"] = "Beschreibung",
            ["detail.day"] = "Tag",
            ["detail.time"] = "Uhrzeit",
            ["detail.close"] = "Schließen",
            ["detail.delete"] = "Löschen",
            ["week.empty"] = "Keine Einträge",
            ["agenda.empty"] = "Keine geplanten Termine.",
            ["agenda.notesTitle"] = "Notizen",
            ["agenda.todoTitle"] = "Aufgaben",
            ["agenda.todoAdd"] = "Hinzufügen",
            ["modal.newItem"] = "Neuer Eintrag",
            ["modal.resource"] = "Ressource",
            ["modal.from"] = "Von",
            ["modal.to"] = "Bis",
            ["modal.description"] = "Beschreibung",
            ["modal.cancel"] = "Abbrechen",
            ["modal.save"] = "Speichern",
            ["resources.title"] = "Ressourcen verwalten",
            ["resources.add"] = "Hinzufügen",
            ["resources.close"] = "Schließen",
            ["global.readonlyHint"] = "Nur Lesezugriff — nur Administratoren können bearbeiten",
            ["detail.empty"] = "Keine Einträge.",
            ["users.title"] = "Benutzer verwalten",
            ["users.close"] = "Schließen",
            ["users.create"] = "Erstellen",
        },
        ["en"] = new()
        {
            ["app.title"] = "Manager",
            ["login.title"] = "LOGIN",
            ["login.username"] = "E-Mail",
            ["login.password"] = "Password",
            ["login.submit"] = "Sign in",
            ["login.errNeedBoth"] = "Please enter a username and password.",
            ["login.errPassword"] = "Incorrect password.",
            ["login.errUserNotFound"] = "User not found.",
            ["nav.today"] = "Today",
            ["view.day"] = "Day",
            ["view.week"] = "Week",
            ["view.agenda"] = "Schedule",
            ["view.global"] = "Global",
            ["detail.allDay"] = "All day",
            ["detail.description"] = "Description",
            ["detail.day"] = "Day",
            ["detail.time"] = "Time",
            ["detail.close"] = "Close",
            ["detail.delete"] = "Delete",
            ["week.empty"] = "No items",
            ["agenda.empty"] = "No events scheduled.",
            ["agenda.notesTitle"] = "Notes",
            ["agenda.todoTitle"] = "To-do",
            ["agenda.todoAdd"] = "Add",
            ["modal.newItem"] = "New item",
            ["modal.resource"] = "Resource",
            ["modal.from"] = "From",
            ["modal.to"] = "To",
            ["modal.description"] = "Description",
            ["modal.cancel"] = "Cancel",
            ["modal.save"] = "Save",
            ["resources.title"] = "Manage resources",
            ["resources.add"] = "Add",
            ["resources.close"] = "Close",
            ["global.readonlyHint"] = "Read-only — only administrators can edit",
            ["detail.empty"] = "No items.",
            ["users.title"] = "Manage users",
            ["users.close"] = "Close",
            ["users.create"] = "Create",
        }
    };

    public event Action? OnLanguageChanged;

    public void SetLanguage(string lang)
    {
        if (!Dict.ContainsKey(lang)) return;
        CurrentLang = lang;
        OnLanguageChanged?.Invoke();
    }

    public string T(string key)
    {
        if (Dict[CurrentLang].TryGetValue(key, out var val)) return val;
        if (Dict["it"].TryGetValue(key, out var fallback)) return fallback;
        return key;
    }

    public string Locale => CurrentLang switch
    {
        "de" => "de-DE",
        "en" => "en-GB",
        _ => "it-IT"
    };
}
