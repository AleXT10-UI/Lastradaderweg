using GestionaleBlazor.Models;

namespace GestionaleBlazor.Services;

public class GlobalTimelineService
{
    private readonly StorageService _storage;

    public List<string> Resources { get; private set; } = new();
    public Dictionary<string, List<Booking>> Bookings { get; private set; } = new();

    private int _idCounter = 1;

    public GlobalTimelineService(StorageService storage)
    {
        _storage = storage;
    }

    public async Task LoadAsync()
    {
        Resources = await _storage.LoadGlobalResourcesAsync();
        Bookings = await _storage.LoadGlobalBookingsAsync();
        _idCounter = ComputeMaxId(Bookings) + 1;
    }

    private static int ComputeMaxId(Dictionary<string, List<Booking>> bookings)
    {
        var max = 0;
        foreach (var list in bookings.Values)
            foreach (var b in list)
                if (b.Id > max) max = b.Id;
        return max;
    }

    public List<Booking> GetForDate(string dateKey)
        => Bookings.TryGetValue(dateKey, out var list) ? list : new List<Booking>();

    public async Task AddBookingAsync(string dateKey, string res, double start, double end, string label, bool allDay)
    {
        if (!Bookings.TryGetValue(dateKey, out var list))
        {
            list = new List<Booking>();
            Bookings[dateKey] = list;
        }
        list.Add(new Booking
        {
            Id = _idCounter++,
            Res = res,
            Start = start,
            End = end,
            Label = label,
            AllDay = allDay
        });
        await _storage.SaveGlobalBookingsAsync(Bookings);
    }

    public async Task RemoveBookingAsync(string dateKey, int id)
    {
        if (!Bookings.TryGetValue(dateKey, out var list)) return;
        list.RemoveAll(b => b.Id == id);
        if (list.Count == 0) Bookings.Remove(dateKey);
        await _storage.SaveGlobalBookingsAsync(Bookings);
    }

    public async Task AddResourceAsync(string name)
    {
        if (Resources.Contains(name)) return;
        Resources.Add(name);
        await _storage.SaveGlobalResourcesAsync(Resources);
    }

    public async Task RemoveResourceAsync(string name)
    {
        if (Resources.Count <= 1) return;
        Resources.Remove(name);
        await _storage.SaveGlobalResourcesAsync(Resources);
    }

    public async Task ReorderAsync(int fromIndex, int toIndex)
    {
        var moved = Resources[fromIndex];
        Resources.RemoveAt(fromIndex);
        Resources.Insert(toIndex, moved);
        await _storage.SaveGlobalResourcesAsync(Resources);
    }
}
