using GestionaleBlazor.Models;

namespace GestionaleBlazor.Services;

public class UserManagementService
{
    private readonly StorageService _storage;
    private const string AdminUsername = "admin";

    public Dictionary<string, AppUser> Users { get; private set; } = new();

    public UserManagementService(StorageService storage)
    {
        _storage = storage;
    }

    public async Task LoadAsync()
    {
        Users = await _storage.LoadUsersAsync();
    }

    public async Task<string?> AddUserAsync(string username, string password)
    {
        if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            return "users.needBoth";
        if (username == AdminUsername)
            return "users.reserved";
        if (Users.ContainsKey(username))
            return "users.exists";

        Users[username] = new AppUser
        {
            Username = username,
            PasswordHash = AuthService.Sha256(password),
            CanAnnounce = false
        };
        await _storage.SaveUsersAsync(Users);
        return null;
    }

    public async Task DeleteUserAsync(string username)
    {
        Users.Remove(username);
        await _storage.SaveUsersAsync(Users);
    }

    public async Task SetCanAnnounceAsync(string username, bool value)
    {
        if (!Users.TryGetValue(username, out var user)) return;
        user.CanAnnounce = value;
        await _storage.SaveUsersAsync(Users);
    }
}
