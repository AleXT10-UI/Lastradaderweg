using Microsoft.EntityFrameworkCore;
using GestionaleBlazor.Data;
using GestionaleBlazor.Models;

namespace GestionaleBlazor.Services;

public class StorageService
{
    private readonly IDbContextFactory<AppDbContext> _dbFactory;
    private const string GlobalOwner = "__global__";

    public StorageService(IDbContextFactory<AppDbContext> dbFactory)
    {
        _dbFactory = dbFactory;
    }

    public async Task<Dictionary<string, AppUser>> LoadUsersAsync()
    {
        await using var db = await _dbFactory.CreateDbContextAsync();
        var list = await db.Users.ToListAsync();
        return list.ToDictionary(u => u.Username);
    }

    public async Task SaveUsersAsync(Dictionary<string, AppUser> users)
    {
        await using var db = await _dbFactory.CreateDbContextAsync();
        foreach (var user in users.Values)
        {
            var existing = await db.Users.FindAsync(user.Username);
            if (existing is null)
                db.Users.Add(user);
            else
            {
                existing.PasswordHash = user.PasswordHash;
                existing.CanAnnounce = user.CanAnnounce;
            }
        }
        var currentKeys = users.Keys.ToHashSet();
        var toRemove = await db.Users.Where(u => !currentKeys.Contains(u.Username)).ToListAsync();
        db.Users.RemoveRange(toRemove);
        await db.SaveChangesAsync();
    }

    public Task<List<string>> LoadResourcesAsync(string username) => LoadResourcesForOwnerAsync(username);
    public Task SaveResourcesAsync(string username, List<string> resources) => SaveResourcesForOwnerAsync(username, resources);
    public Task<List<string>> LoadGlobalResourcesAsync() => LoadResourcesForOwnerAsync(GlobalOwner);
    public Task SaveGlobalResourcesAsync(List<string> resources) => SaveResourcesForOwnerAsync(GlobalOwner, resources);

    private async Task<List<string>> LoadResourcesForOwnerAsync(string owner)
    {
        await using var db = await _dbFactory.CreateDbContextAsync();
        var items = await db.Resources
            .Where(r => r.Owner == owner)
            .OrderBy(r => r.SortOrder)
            .ToListAsync();

        if (items.Count == 0)
        {
            var defaults = DefaultResources();
            await SaveResourcesForOwnerAsync(owner, defaults);
            return defaults;
        }

        return items.Select(r => r.Name).ToList();
    }

    private async Task SaveResourcesForOwnerAsync(string owner, List<string> resources)
    {
        await using var db = await _dbFactory.CreateDbContextAsync();
        var existing = await db.Resources.Where(r => r.Owner == owner).ToListAsync();
        db.Resources.RemoveRange(existing);

        for (var i = 0; i < resources.Count; i++)
        {
            db.Resources.Add(new ResourceItem { Owner = owner, Name = resources[i], SortOrder = i });
        }
        await db.SaveChangesAsync();
    }

    public Task<Dictionary<string, List<Booking>>> LoadBookingsAsync(string username) => LoadBookingsForOwnerAsync(username);
    public Task SaveBookingsAsync(string username, Dictionary<string, List<Booking>> bookings) => SaveBookingsForOwnerAsync(username, bookings);
    public Task<Dictionary<string, List<Booking>>> LoadGlobalBookingsAsync() => LoadBookingsForOwnerAsync(GlobalOwner);
    public Task SaveGlobalBookingsAsync(Dictionary<string, List<Booking>> bookings) => SaveBookingsForOwnerAsync(GlobalOwner, bookings);

    private async Task<Dictionary<string, List<Booking>>> LoadBookingsForOwnerAsync(string owner)
    {
        await using var db = await _dbFactory.CreateDbContextAsync();
        var items = await db.Bookings.Where(b => b.Owner == owner).ToListAsync();
        return items
            .GroupBy(b => b.DateKey)
            .ToDictionary(g => g.Key, g => g.ToList());
    }

    private async Task SaveBookingsForOwnerAsync(string owner, Dictionary<string, List<Booking>> bookings)
    {
        await using var db = await _dbFactory.CreateDbContextAsync();
        var existing = await db.Bookings.Where(b => b.Owner == owner).ToListAsync();
        db.Bookings.RemoveRange(existing);

        foreach (var (dateKey, list) in bookings)
        {
            foreach (var booking in list)
            {
                booking.Owner = owner;
                booking.DateKey = dateKey;
                db.Bookings.Add(booking);
            }
        }
        await db.SaveChangesAsync();
    }

    public async Task<Announcement?> LoadAnnouncementAsync()
    {
        await using var db = await _dbFactory.CreateDbContextAsync();
        return await db.Announcements.OrderByDescending(a => a.Id).FirstOrDefaultAsync();
    }

    public async Task SaveAnnouncementAsync(Announcement announcement)
    {
        await using var db = await _dbFactory.CreateDbContextAsync();
        var existing = await db.Announcements.OrderByDescending(a => a.Id).FirstOrDefaultAsync();
        if (existing is null)
        {
            db.Announcements.Add(announcement);
        }
        else
        {
            existing.Date = announcement.Date;
            existing.Text = announcement.Text;
            existing.CheckedByCsv = announcement.CheckedByCsv;
        }
        await db.SaveChangesAsync();
    }

    public async Task DeleteAnnouncementAsync()
    {
        await using var db = await _dbFactory.CreateDbContextAsync();
        var all = await db.Announcements.ToListAsync();
        db.Announcements.RemoveRange(all);
        await db.SaveChangesAsync();
    }

    public async Task<string> LoadAgendaNotesAsync(string username)
    {
        await using var db = await _dbFactory.CreateDbContextAsync();
        var note = await db.AgendaNotes.FindAsync(username);
        return note?.Text ?? "";
    }

    public async Task SaveAgendaNotesAsync(string username, string notes)
    {
        await using var db = await _dbFactory.CreateDbContextAsync();
        var existing = await db.AgendaNotes.FindAsync(username);
        if (existing is null)
            db.AgendaNotes.Add(new AgendaNote { Owner = username, Text = notes });
        else
            existing.Text = notes;
        await db.SaveChangesAsync();
    }

    public async Task<List<TodoItem>> LoadTodosAsync(string username)
    {
        await using var db = await _dbFactory.CreateDbContextAsync();
        return await db.Todos.Where(t => t.Owner == username).ToListAsync();
    }

    public async Task SaveTodosAsync(string username, List<TodoItem> todos)
    {
        await using var db = await _dbFactory.CreateDbContextAsync();
        var existing = await db.Todos.Where(t => t.Owner == username).ToListAsync();
        db.Todos.RemoveRange(existing);
        foreach (var todo in todos)
        {
            todo.Owner = username;
            db.Todos.Add(todo);
        }
        await db.SaveChangesAsync();
    }

    private static List<string> DefaultResources()
        => new() { "1", "2", "3", "4", "5", "6", "7", "8" };
}
