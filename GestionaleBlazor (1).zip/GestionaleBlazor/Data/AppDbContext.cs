using Microsoft.EntityFrameworkCore;
using GestionaleBlazor.Models;

namespace GestionaleBlazor.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Booking> Bookings => Set<Booking>();
    public DbSet<AppUser> Users => Set<AppUser>();
    public DbSet<Announcement> Announcements => Set<Announcement>();
    public DbSet<TodoItem> Todos => Set<TodoItem>();
    public DbSet<ResourceItem> Resources => Set<ResourceItem>();
    public DbSet<AgendaNote> AgendaNotes => Set<AgendaNote>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<AppUser>().HasKey(u => u.Username);
        modelBuilder.Entity<AgendaNote>().HasKey(n => n.Owner);

        modelBuilder.Entity<Booking>()
            .HasIndex(b => new { b.Owner, b.DateKey });

        modelBuilder.Entity<ResourceItem>()
            .HasIndex(r => new { r.Owner, r.Name })
            .IsUnique();

        modelBuilder.Entity<TodoItem>()
            .HasIndex(t => t.Owner);
    }
}
